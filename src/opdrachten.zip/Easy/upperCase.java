package Easy;

public class upperCase {
/*
    public static void main(String[] args) {

        String List[] = {"Hola", "Hallo", "Bonjour", "gutenmorgen", "Hello"};
        for (String str : List){
            System.out.println(str);
    }

        public static List<String> upperCase (List<String> list){

            return (double) sum/List.length;
        }
        */
}
