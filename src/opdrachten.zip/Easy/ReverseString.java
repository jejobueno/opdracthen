package Easy;

public class ReverseString {

    public static void main(String[] args) {

        String s = "java interview";

        String reverse = "";
        for (int i = s.length() - 1; i >= 0; i--) {
            reverse = reverse + s.charAt(i);
        }

        System.out.println(reverse);

    }
}
